#!/usr/bin/env bash

# System requirements
sudo python install/install_system.py

# Python requirements
sudo pip install -r requirements.txt
