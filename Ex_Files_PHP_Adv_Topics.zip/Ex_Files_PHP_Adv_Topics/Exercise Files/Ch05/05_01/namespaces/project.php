<?php
namespace Project;
class Table {
	public static function get() {
		echo "Project.Table.get \n";
	}
}