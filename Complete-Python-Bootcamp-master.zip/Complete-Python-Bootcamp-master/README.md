# Complete-Python-Bootcamp

## Welcome to the Repository for the Complete Python Bootcamp!

This is the Repository for the Udemy course - "Complete Python Bootcamp".

You can purchase the course at a 50% discount by clicking [here](https://www.udemy.com/complete-python-bootcamp/?couponCode=PYTHON15). 
Purchasing the course grants access to all the screencast videos and the moderated discussion forums!


In this repo you will find all the accompanying Jupyter (p.k.a. iPython) Notebooks for the course. For quicker view rendering and simpler downloading procedures, you can check out this repo using [NbViewer](http://nbviewer.ipython.org/github/jmportilla/Complete-Python-Bootcamp/tree/master/).


Then navigate to your desired lecture and enjoy! You can download the .ipynb files onto your own computer for convenience.

Enjoy the course and thank you for enrolling!
