module.exports = {
    "vera": {
        "api": {
            "useRemote": false
        },
        "scenes": {} //@todo Remove
    },
    "crontab": {
        "user": "root"
    },
    "log": {
        "level": "info"
    },
    "pushbullet": {},
    "api": {
        "accessTokens": [],
        "port": 80,
        "isSecure": false
    },
    "location": {}
};
